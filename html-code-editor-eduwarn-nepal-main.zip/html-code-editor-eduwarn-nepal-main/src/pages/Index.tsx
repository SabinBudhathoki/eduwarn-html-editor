
import CodeEditor from "@/components/CodeEditor";

const Index = () => {
  return <CodeEditor />;
};

export default Index;
